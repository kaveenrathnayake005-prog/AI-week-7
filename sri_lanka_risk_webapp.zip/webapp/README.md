# Sri Lanka Road Accident Risk Predictor v5.0 — Web App

AI-powered road safety analysis system for all 25 districts of Sri Lanka.

## 🚀 Deploy to Render.com (FREE — 5 minutes)

1. Go to https://render.com and sign up free
2. Click **New → Web Service**
3. Choose **"Deploy from existing code"** or connect GitHub
4. Upload this folder
5. Set:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app --bind 0.0.0.0:$PORT --workers 1 --timeout 120`
6. Click **Deploy** → you get a public URL like `https://your-app.onrender.com`

## 🚀 Deploy to Railway.app (FREE — 3 minutes)

1. Go to https://railway.app
2. New Project → **Deploy from local folder**
3. Upload this folder → it auto-detects Flask
4. Done — public URL in minutes

## 🖥️ Run Locally

```bash
pip install -r requirements.txt
python app.py
# Open http://localhost:5000
```

## 🌐 Public URL via ngrok (instant)

```bash
# Terminal 1
python app.py

# Terminal 2
ngrok http 5000
# Copy the https://xxxxx.ngrok.io URL — share it with anyone!
```

## Features

- 🗺️ Route Planner with BFS pathfinding across 25 districts
- 🤖 Random Forest AI (200 trees, 80%+ accuracy)
- 📊 Risk Score Gauge (0-100)
- 🏛️ Province Risk Summary
- 🛣️ Per-segment risk analysis with probability bars
- 💡 Smart context-aware safety tips
- 🔊 Detailed safety advice per risk level

## Tech Stack

- **Backend:** Python, Flask, scikit-learn, pandas
- **Frontend:** Pure HTML/CSS/JavaScript (no frameworks)
- **Model:** Random Forest Classifier (3,000 training records, 12 features)
